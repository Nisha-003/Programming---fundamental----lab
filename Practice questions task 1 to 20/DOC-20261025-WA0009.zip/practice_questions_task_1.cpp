#include <iostream>
using namespace std;

// Task 1: Print numbers divisible by 3 from 1 to 30
int main()
{
    for (int i = 1; i <= 30; i++)
    {
        if (i % 3 == 0)
        {
            cout << i << " ";
        }
    }

    return 0;
}
