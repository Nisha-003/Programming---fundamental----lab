#include <iostream>
using namespace std;

// Task 8: Prime numbers between 2 and 100
int main()
{
    int i, j, prime;

    for (i = 2; i <= 100; i++)
    {
        prime = 1;

        for (j = 2; j < i; j++)
        {
            if (i % j == 0)
            {
                prime = 0;
                break;
            }
        }

        if (prime == 1)
        {
            cout << i << " ";
        }
    }

    return 0;
}
