#include <iostream>
using namespace std;

// Task 2: Calculate sum and average of 8 numbers
int main()
{
    int num, sum = 0;
    float average;

    for (int i = 1; i <= 8; i++)
    {
        cout << "Enter number " << i << ": ";
        cin >> num;
        sum = sum + num;
    }

    average = sum / 8.0;

    cout << "Sum = " << sum << endl;
    cout << "Average = " << average << endl;

    return 0;
}
