#include <iostream>
using namespace std;

// Task 14: Check whether a number is Palindrome or not
int main()
{
    int n, originalNum, reversedNum = 0, remainder;
    cout << "Enter an integer: ";
    cin >> n;

    originalNum = n;

    while (n != 0)
    {
        remainder = n % 10;
        reversedNum = reversedNum * 10 + remainder;
        n /= 10;
    }

    if (originalNum == reversedNum)
        cout << originalNum << " is a Palindrome." << endl;
    else
        cout << originalNum << " is not a Palindrome." << endl;

    return 0;
}
