#include <iostream>
using namespace std;

// Task 3: Print first 12 terms of Fibonacci Series
int main()
{
    int a = 0, b = 1, next;

    cout << "Fibonacci Series: ";

    for (int i = 1; i <= 12; i++)
    {
        cout << a << " ";

        next = a + b;
        a = b;
        b = next;
    }

    return 0;
}
