#include <iostream>
#include <string>
using namespace std;

// Task 18: Count vowels and consonants in a string
int main()
{
    string str;
    int vowels = 0, consonants = 0;

    cout << "Enter a string (without spaces): ";
    cin >> str;

    for (int i = 0; i < str.length(); i++)
    {
        char ch = tolower(str[i]);
        if (ch >= 'a' && ch <= 'z')
        {
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u')
                vowels++;
            else
                consonants++;
        }
    }

    cout << "Vowels: " << vowels << endl;
    cout << "Consonants: " << consonants << endl;

    return 0;
}
