#include <iostream>
using namespace std;

// Task 9: Sum numbers until a negative number is entered
int main()
{
    int num, sum = 0;

    while (true)
    {
        cout << "Enter a number: ";
        cin >> num;

        if (num < 0)
        {
            break;
        }

        sum = sum + num;
    }

    cout << "Sum = " << sum << endl;

    return 0;
}
