#include <iostream>
using namespace std;

// Task 13: Count even and odd numbers in an array
int main()
{
    int n, evenCount = 0, oddCount = 0;
    cout << "Enter total numbers: ";
    cin >> n;

    int arr[100];
    cout << "Enter " << n << " numbers: ";
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
        if (arr[i] % 2 == 0)
            evenCount++;
        else
            oddCount++;
    }

    cout << "Total Even Numbers: " << evenCount << endl;
    cout << "Total Odd Numbers: " << oddCount << endl;

    return 0;
}
