#include <iostream>
using namespace std;

// Task 20: Function to print multiplication table
void printTable(int n)
{
    cout << "Multiplication Table of " << n << ":\n";
    for (int i = 1; i <= 10; i++)
    {
        cout << n << " x " << i << " = " << n * i << endl;
    }
}

int main()
{
    int number;
    cout << "Enter a number to print its table: ";
    cin >> number;

    printTable(number);

    return 0;
}
